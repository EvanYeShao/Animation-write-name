//
//  ViewController.m
//  NameSign
//
//  Created by Evan on 16/7/4.
//  Copyright © 2016年 Evan. All rights reserved.
//

//  shapeLayer.lineJoin = kCALineJoinBevel;
//  lineJoin:要使用的接合类型
//  kCGLineJoinMiter
//  接合点为尖角。这是默认的接合类型。
//  kCGLineJoinBevel
//  接合点为斜角
//  kCGLineJoinRound
//  接合点为圆角

#import "ViewController.h"
#import <Coretext/Coretext.h>

@interface ViewController ()<UITextFieldDelegate>

@property (nonatomic, strong) CALayer *penLayer;

@property (nonatomic, weak) CAShapeLayer *shapeLayer;

@property (nonatomic, weak) UITextField *nameTitleFile;

@property (nonatomic, weak) UIButton *determineButton;

@end

@implementation ViewController

#pragma mark - Control
- (CAShapeLayer *)shapeLayer
{
    if (!_shapeLayer)
    {
        CAShapeLayer *shapeLayer = [[CAShapeLayer alloc] init];
        
        shapeLayer.frame = self.view.bounds;
        shapeLayer.geometryFlipped = YES;//翻转
        shapeLayer.strokeColor = [[UIColor blackColor] CGColor];
        shapeLayer.fillColor = nil;
        shapeLayer.lineWidth = 3.0f;
        shapeLayer.lineJoin = kCALineJoinBevel;
        
        self.shapeLayer = shapeLayer;
        [self.view.layer addSublayer:shapeLayer];
    }
    return _shapeLayer;
}

- (UITextField *)nameTitleFile
{
    if (!_nameTitleFile)
    {
        UITextField *nameTitleFile = [[UITextField alloc] init];
        
        nameTitleFile.frame = CGRectMake(10, 64, [UIScreen mainScreen].bounds.size.width - 20, 44);
        nameTitleFile.layer.borderWidth = 0.5f;
        nameTitleFile.layer.borderColor = [UIColor grayColor].CGColor;
        nameTitleFile.placeholder = @"请输入名称";
        nameTitleFile.font = [UIFont systemFontOfSize:13];
        
        self.nameTitleFile = nameTitleFile;
        [self.view addSubview:nameTitleFile];
    }
    return _nameTitleFile;
}

- (UIButton *)determineButton
{
    if (!_determineButton)
    {
        UIButton *determineButton = [[UIButton alloc] init];
        
        determineButton.frame = CGRectMake(10, 118, [UIScreen mainScreen].bounds.size.width - 20, 44);
        [determineButton setTitle:@"确定" forState:UIControlStateNormal];
        [determineButton setBackgroundColor:[UIColor redColor]];
        [determineButton addTarget:self action:@selector(determineButtonClick) forControlEvents:UIControlEventTouchUpInside];
        
        self.determineButton = determineButton;
        [self.view addSubview:determineButton];
    }
    return _determineButton;
}

#pragma mark - LfileCycle
- (void)viewDidLoad
{
    [super viewDidLoad];

    self.title = @"名字签写";
    
    self.nameTitleFile.delegate = self;
    self.determineButton;
}

#pragma mark - Touch Event
- (void)determineButtonClick
{
    [self setupTextLayer];
    [self startAnimation];
}

#pragma mark - setupTextLayer
- (void)setupTextLayer
{
    if (self.shapeLayer != nil)
    {
        [self.penLayer removeFromSuperlayer];
        [self.shapeLayer removeFromSuperlayer];
        self.shapeLayer = nil;
        self.penLayer = nil;
    }
    
    // 曲线动画的path
    CGMutablePathRef letters = CGPathCreateMutable();
    // 文字格式和大小
    CTFontRef font = CTFontCreateWithName(CFSTR("Helvetica-Bold"), 46.0, NULL);
    
    NSDictionary *attrs = [NSDictionary dictionaryWithObjectsAndKeys:
                           (__bridge id)font, kCTFontAttributeName,nil];
    // 文字
    NSAttributedString *attrString = [[NSAttributedString alloc] initWithString:self.nameTitleFile.text
                                                                     attributes:attrs];
    
    // 参考线
    CTLineRef line = CTLineCreateWithAttributedString((CFAttributedStringRef)attrString);
    // CTLineGetGlyphRuns:构成线的ctrun对象。
    CFArrayRef runArray = CTLineGetGlyphRuns(line);
    
    // 每次运行
    for (CFIndex runIndex = 0; runIndex < CFArrayGetCount(runArray); runIndex++)
    {
        // 获取运行的字体,
        // CTRunRef:运行参考
        CTRunRef run = (CTRunRef)CFArrayGetValueAtIndex(runArray, runIndex);
        CTFontRef runFont = CFDictionaryGetValue(CTRunGetAttributes(run), kCTFontAttributeName);
        
        // 对于运行中的每个符号
        // CTRunGetGlyphCount:运行获得字形计数
        for (CFIndex runGlyphIndex = 0; runGlyphIndex < CTRunGetGlyphCount(run); runGlyphIndex++)
        {
            // 获取字形和字形数据
            CFRange thisGlyphRange = CFRangeMake(runGlyphIndex, 1);// 范围
            CGGlyph glyph;// 雕文
            CGPoint position;// 位置
            CTRunGetGlyphs(run, thisGlyphRange, &glyph);
            CTRunGetPositions(run, thisGlyphRange, &position);
            
            // 获取轮廓路径
            {
                CGPathRef letter = CTFontCreatePathForGlyph(runFont, glyph, NULL);
                CGAffineTransform t = CGAffineTransformMakeTranslation(position.x, position.y);
                CGPathAddPath(letters, &t, letter);
                CGPathRelease(letter);
            }
        }
    }
    CFRelease(line);
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointZero];
    [path appendPath:[UIBezierPath bezierPathWithCGPath:letters]];
    
    CGPathRelease(letters);
    CFRelease(font);
    
    self.shapeLayer.path = path.CGPath;
    self.shapeLayer.bounds = CGPathGetBoundingBox(path.CGPath);
    
    UIImage *penImage = [UIImage imageNamed:@"noun_project_347_2.png"];
    CALayer *penLayer = [CALayer layer];
    penLayer.contents = (id)penImage.CGImage;
    penLayer.anchorPoint = CGPointZero;
    penLayer.frame = CGRectMake(0.0f, 0.0f, penImage.size.width, penImage.size.height);
    [self.shapeLayer addSublayer:penLayer];
    
    self.penLayer = penLayer;
}

#pragma mark - startAnimation
- (void)startAnimation
{
    [self.shapeLayer removeAllAnimations];
    [self.penLayer removeAllAnimations];
    
    self.penLayer.hidden = NO;
    
    CABasicAnimation *pathAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    pathAnimation.duration = 10.0;
    pathAnimation.fromValue = [NSNumber numberWithFloat:0.0f];
    pathAnimation.toValue = [NSNumber numberWithFloat:1.0f];
    [self.shapeLayer addAnimation:pathAnimation forKey:@"strokeEnd"];
    
    CAKeyframeAnimation *penAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    penAnimation.duration = 10.0;
    penAnimation.path = self.shapeLayer.path;
    penAnimation.calculationMode = kCAAnimationPaced;
    penAnimation.delegate = self;
    
    
    penAnimation.removedOnCompletion = NO;
    penAnimation.fillMode = kCAFillModeForwards;
    
    [self.penLayer addAnimation:penAnimation forKey:@"position"];
}

@end
